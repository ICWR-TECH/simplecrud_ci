<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>CRUD CI | Edit data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  </head>
  <body class="container">
    <h1 class="mt-5">Edit data</h1>
    <br>
    <form class="form-group" action="<?php echo base_url('/crud/edit/'.$id->id) ?>" method="post">
      <input type="text" name="judul" class="form-control <?php echo form_error('judul') ? 'is-invalid':'' ?>" value="" placeholder="Judul...">
      <div class="invalid-feedback">
        <?php echo form_error('judul') ?>
      </div>
      <br>
      <textarea name="isi" rows="8" cols="80" class="form-control <?php echo form_error("isi")?'is-invalid':'' ?>" placeholder="Isi..."></textarea>
      <div class="invalid-feedback">
        <?php echo form_error('isi') ?>
      </div>
      <br>
      <input type="text" name="author" class="form-control <?php echo form_error('author') ? 'is-invalid':'' ?>" value="" placeholder="Author...">
      <div class="invalid-feedback">
        <?php
          echo form_error("author");
        ?>
      </div>
      <br>
      <input type="text" name="konten" class="form-control <?php echo form_error('konten') ? 'is-invalid':'' ?>" value="" placeholder="Konten...">
      <div class="invalid-feedback">
        <?php echo form_error('konten') ?>
      </div>
      <br>
      <input type="submit" name="submit" value="Submit" class="btn btn-success">
    </form>
    <?php if($this->session->flashdata("success")){ ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Data berhasil diperbarui!</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php } ?>
  </body>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</html>
