<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title><?php echo "CRUD CI | ".$tampil->judul ?></title>
  </head>
  <body class="container">
    <div class="jumbotron mt-5">
      <h1 class=""><?php echo $tampil->judul; ?></h1>
      <p class="mt-4"><?php echo $tampil->isi; ?></p>
      <blockquote class=" text-left mt-5">
      	<footer style="opacity:0.7">
          <?php echo "<b>Tanggal upload: </b>".$tampil->tanggal; ?>
          <br>
          <?php echo "<b>Author: </b>".$tampil->author; ?>
          <br>
          <?php echo "<b>Konten: </b>".$tampil->konten; ?>
        </footer>
      </blockquote>
      <br><br><br>
    </div>
        <a href="<?php echo base_url() ?>" class="btn btn-primary">Halaman awal</a>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>
