<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Simple CRUD CI</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  </head>
  <body class="container">
    <h1 class="mt-5">Simple CRUD CI</h1>
    <br>
    <?php
    if($this->session->flashdata("success_update")){
    ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo $this->session->flashdata("success_update") ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <br>
    <?php
    }
     ?>

     <?php
     if($this->session->flashdata("success_delete")){
     ?>
       <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong><?php echo $this->session->flashdata("success_delete") ?></strong>
         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
           <span aria-hidden="true">&times;</span>
         </button>
       </div>
       <br>
     <?php
     }
      ?>
    <a href="<?php echo base_url()."create" ?>" class="btn btn-primary">Tambah data</a>
    <br>
    <?php foreach($tampil as $var){ ?>
      <div class="card mt-3">
        <div class="card-header text-center">
          <h3>
          <?php echo $var->judul; ?>
          </h3>
        </div>
        <div class="card-body text-center">
          <p class="card-text">
            <?php echo substr($var->isi,0,150) ?>
          </p>
        </div>
        <div class="card-footer text-muted">
          <a href="<?php echo base_url()."crud/view/".$var->id; ?>" class="badge badge-primary" style="">Read more...</a>
          <a href="<?php echo base_url()."crud/edit/".$var->id; ?>" class="badge badge-warning" style="">Edit</a>
          <a href="<?php echo base_url()."crud/delete/".$var->id; ?>" class="badge badge-danger" style="">Delete</a>
        </div>
      </div>
    <?php } ?>
  </body>
  <br><br>
  <blockquote class="text-center mt-5">
    <footer style="opacity:0.5">
      Powered by ICWR-TECH
    </footer>
  </blockquote>
  <br>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</html>
