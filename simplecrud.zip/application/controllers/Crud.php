<?php
error_reporting(0);
/**
 *
 */
class Crud extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    $this->load->model("Mcrud");
    $this->load->library("form_validation");
  }
  function tampil_artikel(){
    $data['tampil']=$this->Mcrud->tampilsemua("crud");
    $this->load->view("hal_pertama",$data);
  }
  function view($id=null){
    if(!$id) show_404();
    $data['tampil']=$this->Mcrud->tampil_id(['id'=>$id],"crud");
    $this->load->view("lihat_id",$data);
  }
  function upload(){
    date_default_timezone_set('Asia/Jakarta');
    $judul=htmlentities($this->input->post("judul"));
    $isi=htmlentities($this->input->post("isi"));
    $tanggal=date("Y-m-d H:i:s");
    $author=htmlentities($this->input->post("author"));
    $konten=htmlentities($this->input->post("konten"));
    $id=uniqid();
    $rules=[
      [
        'field'=>"judul",
        "label"=>"Judul",
        "rules"=>"required"
      ],
      [
        "field"=>"isi",
        "label"=>"isi",
        "rules"=>"required"
      ],
      [
        "field"=>"author",
        "label"=>"author",
        "rules"=>"required"
      ],
      [
        "field"=>"konten",
        "label"=>"konten",
        "rules"=>"required"
      ],
    ];
    $data=[
      'id'=>$id,
      "judul"=>$judul,
      "isi"=>$isi,
      "tanggal"=>$tanggal,
      "author"=>$author,
      "konten"=>$konten
    ];
    if($this->form_validation->set_rules($rules)->run()){
      $this->Mcrud->upload("crud",$data);
      $this->session->set_flashdata("success","Berhasil simpan data!");
    }
    $this->load->view("upload");
  }
  function edit($id=null){
    if(!$id) show_404();
    date_default_timezone_set('Asia/Jakarta');
    $judul=htmlentities($this->input->post("judul"));
    $isi=htmlentities($this->input->post("isi"));
    $tanggal=date("Y-m-d H:i:s");
    $author=htmlentities($this->input->post("author"));
    $konten=htmlentities($this->input->post("konten"));
    $uni=uniqid();
    $rules=[
      [
        'field'=>"judul",
        "label"=>"Judul",
        "rules"=>"required"
      ],
      [
        "field"=>"isi",
        "label"=>"isi",
        "rules"=>"required"
      ],
      [
        "field"=>"author",
        "label"=>"author",
        "rules"=>"required"
      ],
      [
        "field"=>"konten",
        "label"=>"konten",
        "rules"=>"required"
      ],
    ];
    $data=[
      'id'=>$uni,
      "judul"=>$judul,
      "isi"=>$isi,
      "tanggal"=>$tanggal,
      "author"=>$author,
      "konten"=>$konten
    ];
    if($this->form_validation->set_rules($rules)->run()){
      $this->Mcrud->edit("crud",$data,['id'=>$id]);
      $this->session->set_flashdata("success_update","Berhasil perbarui data!");
      redirect(base_url());
    }
    $data['id']=$this->Mcrud->tampil_edit($id);
    $this->load->view("edit",$data);
  }
  function delete($id=null){
    if(!$id) show_404();
    $where=['id'=>$id];
    if($this->Mcrud->delete("crud",$where)){
      $this->session->set_flashdata("success_delete","Success hapus data!");
      redirect(base_url());
    }
  }
}

 ?>
