<?php
/**
 *
 */
class Mcrud extends CI_Model
{
  function tampilsemua($db)
  {
    return $this->db->get($db)->result();
  }
  function tampil_id($id,$data){
    return $this->db->get_where($data,$id)->row();
  }
  function upload($table,$data){
    $this->db->insert($table,$data);
  }
  function edit($table,$data,$id){
    $this->db->update($table,$data,$id);
  }
  function tampil_edit($id){
    return $this->db->get_where("crud",['id'=>$id])->row();
  }
  function delete($db,$where){
    return $this->db->delete($db,$where);
  }
}

 ?>
